package com.example.climateapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
